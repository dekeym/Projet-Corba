package prox;

import java.util.ArrayList;

import Chat.Message;
import Chat.ProxyPOA;
import Chat.Talk;

public class ProxyImpl extends ProxyPOA {

	private ArrayList<Talk> listeClt;
	
	
	
	
	public ProxyImpl() {
		super();
		this.listeClt = new ArrayList<Talk>();
		
	}

	@Override
	public void enregistrer(Talk t) {
		listeClt.add(t);

	}

	@Override
	public void afficher(Message msg) {
		for (Talk t : listeClt) {
			t.afficher(msg);
		}
	}
	
	
}

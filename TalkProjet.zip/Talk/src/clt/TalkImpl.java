package clt;


import Chat.Message;
import Chat.TalkPOA;

public class TalkImpl extends TalkPOA {

	@Override
	public void afficher(Message msg) {
		
		// Afficher msg 
		System.out.println(msg.expediteur+ " : " + msg.text);
		
	}
	
}

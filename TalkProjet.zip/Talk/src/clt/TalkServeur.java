package clt;


import org.omg.CORBA.ORB;
import org.omg.CosNaming.NamingContext;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;

import Chat.Proxy;
import Chat.TalkHelper;

public class TalkServeur implements Runnable{
	
	private String id;
	private org.omg.CORBA.ORB orb;
	private org.omg.CosNaming.NamingContext nameRoot;
	private Proxy monP;
	
	public TalkServeur(String id, ORB orb, NamingContext nameRoot, Proxy monP) {
		super();
		this.id = id;
		this.orb = orb;
		this.nameRoot = nameRoot;
		this.monP = monP;
	}

	public void run() {
		try {
	        // Gestion du POA
	        //****************
	        // Recuperation du POA
	        POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

	        // Creation du servant
	        //*********************
	        TalkImpl monTalk = new TalkImpl();

	        // Activer le servant au sein du POA et recuperer son ID
	        byte[] monTalkId = rootPOA.activate_object(monTalk);

	        // Activer le POA manager
	        rootPOA.the_POAManager().activate();


	        // Enregistrement dans le service de nommage
	        //*******************************************
	        // Construction du nom a enregistrer
	        org.omg.CosNaming.NameComponent[] nameToRegister = new org.omg.CosNaming.NameComponent[1];
	        nameToRegister[0] = new org.omg.CosNaming.NameComponent(id,"");

	        // Enregistrement de l'objet CORBA dans le service de noms
	        nameRoot.rebind(nameToRegister,rootPOA.servant_to_reference(monTalk));
	        System.out.println("==> Nom '"+ id + "' est enregistre dans le service de noms.");

	        //String IORServant = orb.object_to_string(rootPOA.servant_to_reference(monTalk));

	        
	        
	        // part CLT
	        // mumuse
	        monP.enregistrer(TalkHelper.narrow(rootPOA.servant_to_reference(monTalk)));
	        
	        
	        // Lancement de l'ORB et mise en attente de requete
	        //**************************************************
	        orb.run();

	    }
		catch (Exception e) {
			e.printStackTrace();
		}
	} // main
}

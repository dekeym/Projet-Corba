package clt;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import Chat.Proxy;
import Chat.ProxyHelper;

public class App {

	public static void main(String[] args) { 

		
		// init
		org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);
		
		try {
			// Recuperation du naming service
			NamingContext nameRoot=org.omg.CosNaming.NamingContextHelper.narrow(orb.resolve_initial_references("NameService"));
			
			BufferedReader entreeClavier = new BufferedReader(new InputStreamReader(System.in));
			
			// RECH PROXY
			// Construction du nom a rechercher
			
			// Saisie du nom de l'objet (si utilisation du service de nommage)
			System.out.println("Entrez proxy nom ?");
			String nomproxy = entreeClavier.readLine();
			
			org.omg.CosNaming.NameComponent[] nameToFind = new org.omg.CosNaming.NameComponent[1];
			nameToFind[0] = new org.omg.CosNaming.NameComponent(nomproxy, "");
			// Recherche aupres du naming service
			org.omg.CORBA.Object objC = nameRoot.resolve(nameToFind);
			System.out.println("Objet '" + nomproxy
					+ "' pr�sent aupres du service de noms.");

			// Transtypage de l'objet CORBA au type convertisseur euro
			Proxy monP = ProxyHelper.narrow(objC);
			
			
	  		// S
			System.out.println("Entrez pseudo ?");
			String pseudo = entreeClavier.readLine();
			TalkServeur partS = new TalkServeur(pseudo, orb, nameRoot, monP);
			
			// C
			TalkSender partC = new TalkSender(pseudo, entreeClavier);
			
			
			// Lancer Threads
			Thread tS = new Thread(partS);
			Thread tC = new Thread(partC)
			;
			tS.start();
			tC.start();
		} catch (InvalidName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotFound e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CannotProceed e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (org.omg.CosNaming.NamingContextPackage.InvalidName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}

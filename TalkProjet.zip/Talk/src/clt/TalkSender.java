package clt;

import java.io.BufferedReader;
import java.io.IOException;

import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import Chat.Message;
import Chat.Proxy;
import Chat.ProxyHelper;

public class TalkSender implements Runnable {
	private String id;
	private BufferedReader entreeClavier;
	private Proxy monP;

	public TalkSender(String id, BufferedReader entreeClavier) {
		super();
		this.id = id;
		this.entreeClavier = entreeClavier;
	}

	public void run() {


		
			try {
				while (true) {
					/* R�cup�rer messages + AFFICHAGES */
					// Saisie du nom de l'objet (si utilisation du service de nommage)
					System.out.println("Votre message :");
					String message = entreeClavier.readLine();

					Message msg = new Message(message, id);

					monP.afficher(msg);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
}

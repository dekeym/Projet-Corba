package Chat;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "Chat.idl"
 * <li> <b>IDL Name</b>      ::Chat::Proxy
 * <li> <b>Repository Id</b> IDL:Chat/Proxy:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Proxy : Chat.Talk {
  ...
};
 * </pre>
 */
public interface Proxy extends Chat.ProxyOperations, Chat.Talk, org.omg.CORBA.portable.IDLEntity {
}

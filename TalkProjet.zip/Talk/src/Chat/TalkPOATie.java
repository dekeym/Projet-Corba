
package Chat;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "Chat.idl"
 * <li> <b>IDL Name</b>      ::Chat::Talk
 * <li> <b>Repository Id</b> IDL:Chat/Talk:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Talk {
  ...
};
 * </pre>
 */
public class TalkPOATie extends TalkPOA {
  private Chat.TalkOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public TalkPOATie (final Chat.TalkOperations _delegate) {
    this._delegate = _delegate;
  }

  public TalkPOATie (final Chat.TalkOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public Chat.TalkOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final Chat.TalkOperations the_delegate) {
    this._delegate = the_delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   void afficher (in Chat.Message msg);
   * </pre>
   */
  public void afficher (Chat.Message msg) {
    this._delegate.afficher(msg);
  }

}

package Chat;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "Chat.idl"
 * <li> <b>IDL Name</b>      ::Chat::Talk
 * <li> <b>Repository Id</b> IDL:Chat/Talk:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Talk {
  ...
};
 * </pre>
 */
public interface Talk extends com.inprise.vbroker.CORBA.Object, Chat.TalkOperations, org.omg.CORBA.portable.IDLEntity {
}

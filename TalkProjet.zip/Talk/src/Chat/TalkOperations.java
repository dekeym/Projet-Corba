package Chat;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "Chat.idl"
 * <li> <b>IDL Name</b>      ::Chat::Talk
 * <li> <b>Repository Id</b> IDL:Chat/Talk:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Talk {
  ...
};
 * </pre>
 */
public interface TalkOperations {
  /**
   * <pre>
   *   void afficher (in Chat.Message msg);
   * </pre>
   */
  public void afficher (Chat.Message msg);

}


package Chat;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "Chat.idl"
 * <li> <b>IDL Name</b>      ::Chat::Proxy
 * <li> <b>Repository Id</b> IDL:Chat/Proxy:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Proxy : Chat.Talk {
  ...
};
 * </pre>
 */
public class ProxyPOATie extends ProxyPOA {
  private Chat.ProxyOperations _delegate;
  private org.omg.PortableServer.POA _poa;

  public ProxyPOATie (final Chat.ProxyOperations _delegate) {
    this._delegate = _delegate;
  }

  public ProxyPOATie (final Chat.ProxyOperations _delegate, 
                              final org.omg.PortableServer.POA _poa) {
    this._delegate = _delegate;
    this._poa = _poa;
  }

  public Chat.ProxyOperations _delegate () {
    return this._delegate;
  }

  public void _delegate (final Chat.ProxyOperations the_delegate) {
    this._delegate = the_delegate;
  }

  public org.omg.PortableServer.POA _default_POA () {
    if (_poa != null) {
      return _poa;
    } 
    else {
      return super._default_POA();
    }
  }

  /**
   * <pre>
   *   void enregistrer (in Chat.Talk t);
   * </pre>
   */
  public void enregistrer (Chat.Talk t) {
    this._delegate.enregistrer(t);
  }

  /**
   * <pre>
   *   void afficher (in Chat.Message msg);
   * </pre>
   */
  public void afficher (Chat.Message msg) {
    this._delegate.afficher(msg);
  }

}

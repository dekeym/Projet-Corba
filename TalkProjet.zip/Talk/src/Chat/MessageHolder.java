package Chat;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "Chat.idl"
 * <li> <b>IDL Name</b>      ::Chat::Message
 * <li> <b>Repository Id</b> IDL:Chat/Message:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct Message {
  ...
};
 * </pre>
 */
public final class MessageHolder implements org.omg.CORBA.portable.Streamable {
public Chat.Message value;

public MessageHolder () {
}

public MessageHolder (final Chat.Message _vis_value) {
  this.value = _vis_value;
}

public void _read (final org.omg.CORBA.portable.InputStream input) {
  value = Chat.MessageHelper.read(input);
}

public void _write (final org.omg.CORBA.portable.OutputStream output) {
  Chat.MessageHelper.write(output, value);
}

public org.omg.CORBA.TypeCode _type () {
  return Chat.MessageHelper.type();
}
}

package Chat;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "Chat.idl"
 * <li> <b>IDL Name</b>      ::Chat::Proxy
 * <li> <b>Repository Id</b> IDL:Chat/Proxy:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * interface Proxy : Chat.Talk {
  ...
};
 * </pre>
 */
public interface ProxyOperations extends Chat.TalkOperations {
  /**
   * <pre>
   *   void enregistrer (in Chat.Talk t);
   * </pre>
   */
  public void enregistrer (Chat.Talk t);

}

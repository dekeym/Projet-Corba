package Chat;

/**
 * <ul>
 * <li> <b>IDL Source</b>    "Chat.idl"
 * <li> <b>IDL Name</b>      ::Chat::Message
 * <li> <b>Repository Id</b> IDL:Chat/Message:1.0
 * </ul>
 * <b>IDL definition:</b>
 * <pre>
 * struct Message {
  ...
};
 * </pre>
 */
public final class Message implements org.omg.CORBA.portable.IDLEntity {
  
  public java.lang.String text;
  
  public java.lang.String expediteur;

  public Message () {
    text = "";
    expediteur = "";
  }

  public Message (final java.lang.String text, 
                  final java.lang.String expediteur) {
    this.text = text;
    this.expediteur = expediteur;
  }

  public java.lang.String toString() {
    final java.lang.StringBuffer _ret = new java.lang.StringBuffer("struct Chat.Message {");
    _ret.append("\n");
    _ret.append("java.lang.String text=");
    _ret.append(text != null?'\"' + text + '\"':null);
    _ret.append(",\n");
    _ret.append("java.lang.String expediteur=");
    _ret.append(expediteur != null?'\"' + expediteur + '\"':null);
    _ret.append("\n");
    _ret.append("}");
    return _ret.toString();
  }

  public boolean equals (java.lang.Object o) {
    if (this == o) return true;
    if (o == null) return false;

    if (o instanceof Chat.Message) {
      final Chat.Message obj = (Chat.Message)o;
      boolean res = true;
      do {
        res = this.text == obj.text ||
         (this.text != null && obj.text != null && this.text.equals(obj.text));
        if (!res) break;
        res = this.expediteur == obj.expediteur ||
         (this.expediteur != null && obj.expediteur != null && this.expediteur.equals(obj.expediteur));
      } while (false);
      return res;
    }
    else {
      return false;
    }
  }
}
